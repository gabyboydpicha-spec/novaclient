package net.nova.setting;

import java.util.List;

/** Réglage générique d'un module. Les sous-classes couvrent les types utilisés par le ClickGUI. */
public abstract class Setting<T> {
    public final String name;
    protected T value;

    protected Setting(String name, T value) {
        this.name = name;
        this.value = value;
    }

    public T get() { return value; }
    public void set(T v) { value = v; }

    /** Interrupteur on/off. */
    public static class Bool extends Setting<Boolean> {
        public Bool(String name, boolean value) { super(name, value); }
        public void toggle() { value = !value; }
    }

    /** Valeur numérique bornée (curseur). */
    public static class Num extends Setting<Double> {
        public final double min, max;

        public Num(String name, double value, double min, double max) {
            super(name, value);
            this.min = min;
            this.max = max;
        }

        @Override
        public void set(Double v) { value = Math.max(min, Math.min(max, v)); }

        public double ratio() { return (value - min) / (max - min); }
        public int asInt() { return (int) Math.round(value); }
    }

    /** Choix dans une liste (cycle au clic). */
    public static class Mode extends Setting<Integer> {
        public final List<String> modes;

        public Mode(String name, int index, String... modes) {
            super(name, index);
            this.modes = List.of(modes);
        }

        public String label() { return modes.get(value); }
        public int index() { return value; }
        public void cycle(int dir) { value = Math.floorMod(value + dir, modes.size()); }
    }

    /** Couleur stockée en HSB (plus simple à éditer dans une UI). */
    public static class Color extends Setting<float[]> {
        public Color(String name, int rgb) {
            super(name, new float[3]);
            setRgb(rgb);
        }

        public void setRgb(int rgb) {
            java.awt.Color.RGBtoHSB((rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255, value);
        }

        public int rgb() { return java.awt.Color.HSBtoRGB(value[0], value[1], value[2]) & 0xFFFFFF; }
    }
}
