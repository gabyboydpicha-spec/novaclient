package net.nova.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.fabricmc.loader.api.FabricLoader;
import net.nova.module.Module;
import net.nova.module.ModuleManager;
import net.nova.setting.Setting;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Sauvegarde / chargement JSON : config/novaclient.json */
public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("novaclient.json");

    private Config() {}

    public static void save() {
        JsonObject root = new JsonObject();
        for (Module m : ModuleManager.all()) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.isEnabled());
            for (Setting<?> s : m.settings) {
                if (s instanceof Setting.Bool b) o.addProperty(s.name, b.get());
                else if (s instanceof Setting.Num n) o.addProperty(s.name, n.get());
                else if (s instanceof Setting.Mode md) o.addProperty(s.name, md.index());
                else if (s instanceof Setting.Color c) {
                    JsonArray hsb = new JsonArray();
                    for (float f : c.get()) hsb.add(f);
                    o.add(s.name, hsb);
                }
            }
            root.add(m.name, o);
        }
        try {
            Files.writeString(FILE, GSON.toJson(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            JsonObject root = GSON.fromJson(Files.readString(FILE), JsonObject.class);
            if (root == null) return;
            for (Module m : ModuleManager.all()) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                for (Setting<?> s : m.settings) {
                    if (!o.has(s.name)) continue;
                    if (s instanceof Setting.Bool b) b.set(o.get(s.name).getAsBoolean());
                    else if (s instanceof Setting.Num n) n.set(o.get(s.name).getAsDouble());
                    else if (s instanceof Setting.Mode md) {
                        int i = o.get(s.name).getAsInt();
                        if (i >= 0 && i < md.modes.size()) md.set(i);
                    } else if (s instanceof Setting.Color c) {
                        JsonArray a = o.getAsJsonArray(s.name);
                        for (int i = 0; i < 3 && i < a.size(); i++) c.get()[i] = a.get(i).getAsFloat();
                    }
                }
                if (o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
