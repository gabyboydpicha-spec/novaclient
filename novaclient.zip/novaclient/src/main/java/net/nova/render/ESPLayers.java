package net.nova.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

/**
 * Couches de rendu "à travers les murs" (test de profondeur désactivé).
 * Point sensible à la version : l'API RenderPipeline a changé à chaque version depuis 1.21.5.
 */
public final class ESPLayers {
    private static final RenderPipeline FILL_PIPELINE = RenderPipelines.register(
            RenderPipeline.builder(RenderPipelines.POSITION_COLOR_SNIPPET)
                    .withLocation(Identifier.of("novaclient", "pipeline/fill_xray"))
                    .withVertexFormat(VertexFormats.POSITION_COLOR, VertexFormat.DrawMode.QUADS)
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withCull(false)
                    .withBlend(BlendFunction.TRANSLUCENT)
                    .build());

    private static final RenderPipeline LINES_PIPELINE = RenderPipelines.register(
            RenderPipeline.builder(RenderPipelines.LINES_SNIPPET)
                    .withLocation(Identifier.of("novaclient", "pipeline/lines_xray"))
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .withDepthWrite(false)
                    .withBlend(BlendFunction.TRANSLUCENT)
                    .build());

    public static final RenderLayer FILL_XRAY = RenderLayer.of(
            "novaclient_fill_xray", 1536, false, true, FILL_PIPELINE,
            RenderLayer.MultiPhaseParameters.builder().build(false));

    public static final RenderLayer LINES_XRAY = RenderLayer.of(
            "novaclient_lines_xray", 1536, false, true, LINES_PIPELINE,
            RenderLayer.MultiPhaseParameters.builder().build(false));

    private ESPLayers() {}
}
