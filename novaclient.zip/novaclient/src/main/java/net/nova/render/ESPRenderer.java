package net.nova.render;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.nova.module.Module;
import net.nova.module.ModuleManager;
import net.nova.module.render.BlockESP;
import org.joml.Matrix4f;

public final class ESPRenderer {
    private ESPRenderer() {}

    public static void render(WorldRenderContext ctx) {
        MatrixStack matrices = ctx.matrixStack();
        VertexConsumerProvider consumers = ctx.consumers();
        if (matrices == null || consumers == null) return;

        Vec3d cam = ctx.camera().getCameraPos();

        for (Module module : ModuleManager.all()) {
            if (!(module instanceof BlockESP esp) || !module.isEnabled()) continue;

            RenderLayer lineLayer = esp.throughWalls.get() ? ESPLayers.LINES_XRAY : RenderLayer.getLines();
            RenderLayer fillLayer = esp.throughWalls.get() ? ESPLayers.FILL_XRAY : RenderLayer.getDebugFilledBox();
            float outlineA = (float) (esp.outlineOpacity.get() / 100.0);
            float fillA = (float) (esp.fillOpacity.get() / 100.0);

            for (BlockESP.Hit hit : esp.hits()) {
                Box box = hit.box().offset(-cam.x, -cam.y, -cam.z);
                float r = ((hit.rgb() >> 16) & 255) / 255f;
                float g = ((hit.rgb() >> 8) & 255) / 255f;
                float b = (hit.rgb() & 255) / 255f;

                if (esp.drawsFill() && fillA > 0f) {
                    drawFilled(matrices, consumers.getBuffer(fillLayer), box, r, g, b, fillA);
                }
                if (esp.drawsOutline() && outlineA > 0f) {
                    VertexRendering.drawBox(matrices, consumers.getBuffer(lineLayer), box, r, g, b, outlineA);
                }
            }

            if (consumers instanceof VertexConsumerProvider.Immediate imm) {
                imm.draw(fillLayer);
                imm.draw(lineLayer);
            }
        }
    }

    private static void drawFilled(MatrixStack matrices, VertexConsumer vc, Box bx,
                                   float r, float g, float b, float a) {
        Matrix4f m = matrices.peek().getPositionMatrix();
        float x1 = (float) bx.minX, y1 = (float) bx.minY, z1 = (float) bx.minZ;
        float x2 = (float) bx.maxX, y2 = (float) bx.maxY, z2 = (float) bx.maxZ;

        quad(vc, m, r, g, b, a, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2); // bas
        quad(vc, m, r, g, b, a, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1); // haut
        quad(vc, m, r, g, b, a, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1); // nord
        quad(vc, m, r, g, b, a, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2); // sud
        quad(vc, m, r, g, b, a, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1); // ouest
        quad(vc, m, r, g, b, a, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2); // est
    }

    private static void quad(VertexConsumer vc, Matrix4f m, float r, float g, float b, float a,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz) {
        vc.vertex(m, ax, ay, az).color(r, g, b, a);
        vc.vertex(m, bx, by, bz).color(r, g, b, a);
        vc.vertex(m, cx, cy, cz).color(r, g, b, a);
        vc.vertex(m, dx, dy, dz).color(r, g, b, a);
    }
}
