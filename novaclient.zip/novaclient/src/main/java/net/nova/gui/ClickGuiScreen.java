package net.nova.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.nova.config.Config;
import net.nova.module.Module;
import net.nova.module.ModuleManager;
import net.nova.setting.Setting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * ClickGUI : un panneau par catégorie, déplaçable.
 * Clic gauche = activer un module, clic droit = déplier ses réglages.
 * Mise en page recalculée à chaque frame ; chaque zone cliquable est enregistrée comme Region.
 */
public class ClickGuiScreen extends Screen {
    private static final int W = 124, HEAD = 20, ROW = 17, SROW = 15;
    private static final int BG = 0xEE15151B, HEADER = 0xFF1E1E28, HOVER = 0x22FFFFFF;
    private static final int ACCENT = 0xFF7C5CFF, TEXT = 0xFFEDEDF2, MUTED = 0xFF8E8EA0, TRACK = 0xFF2A2A36;

    private interface Handler { void on(int button, double mx, double my); }
    private interface Drag { void on(double mx, double my); }
    private record Region(int x1, int y1, int x2, int y2, Handler click, Drag drag) {
        boolean hit(double mx, double my) { return mx >= x1 && mx < x2 && my >= y1 && my < y2; }
    }

    private static final class Panel {
        final Module.Category category;
        int x, y;
        boolean open = true;
        Panel(Module.Category c, int x, int y) { category = c; this.x = x; this.y = y; }
    }

    private static final Map<Module.Category, Panel> PANELS = new EnumMap<>(Module.Category.class);
    private final Set<Module> expandedModules = new HashSet<>();
    private final Set<Setting<?>> expandedColors = new HashSet<>();
    private final List<Region> regions = new ArrayList<>();
    private Region active;
    private double dragOffX, dragOffY;

    public ClickGuiScreen() {
        super(Text.literal("ClickGUI"));
        int x = 20;
        for (Module.Category c : Module.Category.values()) {
            PANELS.computeIfAbsent(c, k -> new Panel(k, 20, 20));
            x += W + 10;
        }
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void removed() { Config.save(); }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);
        regions.clear();

        for (Panel p : PANELS.values()) {
            int y = p.y;
            ctx.fill(p.x, y, p.x + W, y + HEAD, HEADER);
            ctx.fill(p.x, y + HEAD - 2, p.x + W, y + HEAD, ACCENT);
            ctx.drawText(textRenderer, p.category.label, p.x + 6, y + 6, TEXT, true);
            final Panel panel = p;
            regions.add(new Region(p.x, y, p.x + W, y + HEAD, (b, mx, my) -> {
                if (b == 0) { dragOffX = mx - panel.x; dragOffY = my - panel.y; }
                else if (b == 1) panel.open = !panel.open;
            }, (mx, my) -> { panel.x = (int) (mx - dragOffX); panel.y = (int) (my - dragOffY); }));
            y += HEAD;
            if (!p.open) continue;

            for (Module m : ModuleManager.in(p.category)) {
                y = drawModule(ctx, p, m, y, mouseX, mouseY);
            }
        }
    }

    private int drawModule(DrawContext ctx, Panel p, Module m, int y, int mx, int my) {
        boolean hover = mx >= p.x && mx < p.x + W && my >= y && my < y + ROW;
        ctx.fill(p.x, y, p.x + W, y + ROW, BG);
        if (hover) ctx.fill(p.x, y, p.x + W, y + ROW, HOVER);
        if (m.isEnabled()) ctx.fill(p.x, y, p.x + 2, y + ROW, ACCENT);
        ctx.drawText(textRenderer, m.name, p.x + 8, y + 5, m.isEnabled() ? TEXT : MUTED, true);
        String arrow = expandedModules.contains(m) ? "-" : "+";
        ctx.drawText(textRenderer, arrow, p.x + W - 10, y + 5, MUTED, false);
        regions.add(new Region(p.x, y, p.x + W, y + ROW, (b, x, yy) -> {
            if (b == 0) m.toggle();
            else if (b == 1 && !expandedModules.remove(m)) expandedModules.add(m);
        }, null));
        y += ROW;

        if (expandedModules.contains(m)) {
            for (Setting<?> s : m.settings) y = drawSetting(ctx, p, s, y, mx, my);
        }
        return y;
    }

    private int drawSetting(DrawContext ctx, Panel p, Setting<?> s, int y, int mx, int my) {
        int x1 = p.x, x2 = p.x + W;
        ctx.fill(x1, y, x2, y + SROW, 0xF00F0F14);

        if (s instanceof Setting.Bool b) {
            ctx.drawText(textRenderer, b.name, x1 + 8, y + 4, TEXT, false);
            int px = x2 - 24;
            ctx.fill(px, y + 4, px + 16, y + 11, b.get() ? ACCENT : TRACK);
            int knob = b.get() ? px + 9 : px;
            ctx.fill(knob, y + 4, knob + 7, y + 11, 0xFFFFFFFF);
            regions.add(new Region(x1, y, x2, y + SROW, (bt, a, c) -> b.toggle(), null));

        } else if (s instanceof Setting.Num n) {
            ctx.fill(x1 + 6, y + 2, x1 + 6 + (int) ((W - 12) * n.ratio()), y + SROW - 2, 0x887C5CFF);
            ctx.drawText(textRenderer, n.name, x1 + 8, y + 4, TEXT, false);
            String v = String.valueOf(n.asInt());
            ctx.drawText(textRenderer, v, x2 - 8 - textRenderer.getWidth(v), y + 4, MUTED, false);
            final int sx1 = x1 + 6, sw = W - 12;
            Drag setter = (px, py) -> n.set(n.min + (n.max - n.min) * Math.max(0, Math.min(1, (px - sx1) / sw)));
            regions.add(new Region(x1, y, x2, y + SROW, (bt, a, c) -> setter.on(a, c), setter));

        } else if (s instanceof Setting.Mode md) {
            ctx.drawText(textRenderer, md.name, x1 + 8, y + 4, TEXT, false);
            String v = md.label();
            ctx.drawText(textRenderer, v, x2 - 8 - textRenderer.getWidth(v), y + 4, ACCENT, false);
            regions.add(new Region(x1, y, x2, y + SROW, (bt, a, c) -> md.cycle(bt == 1 ? -1 : 1), null));

        } else if (s instanceof Setting.Color c) {
            ctx.drawText(textRenderer, c.name, x1 + 8, y + 4, TEXT, false);
            ctx.fill(x2 - 22, y + 3, x2 - 8, y + SROW - 3, 0xFF000000 | c.rgb());
            regions.add(new Region(x1, y, x2, y + SROW, (bt, a, d) -> {
                if (!expandedColors.remove(c)) expandedColors.add(c);
            }, null));
            y += SROW;
            if (expandedColors.contains(c)) {
                y = colorBar(ctx, p, c, 0, y);
                y = colorBar(ctx, p, c, 1, y);
                y = colorBar(ctx, p, c, 2, y - 0) ;
            }
            return y;
        }
        return y + SROW;
    }

    /** Barre HSB (0 = teinte, 1 = saturation, 2 = luminosité) dessinée colonne par colonne. */
    private int colorBar(DrawContext ctx, Panel p, Setting.Color c, int channel, int y) {
        int x1 = p.x + 8, w = W - 16, h = 9;
        float[] hsb = c.get();
        for (int i = 0; i < w; i++) {
            float t = i / (float) (w - 1);
            float hh = channel == 0 ? t : hsb[0];
            float ss = channel == 1 ? t : (channel == 0 ? 1f : hsb[1]);
            float bb = channel == 2 ? t : (channel == 0 ? 1f : hsb[2]);
            ctx.fill(x1 + i, y + 2, x1 + i + 1, y + 2 + h, 0xFF000000 | (java.awt.Color.HSBtoRGB(hh, ss, bb) & 0xFFFFFF));
        }
        int knobX = x1 + (int) (hsb[channel] * (w - 1));
        ctx.fill(knobX - 1, y + 1, knobX + 1, y + 3 + h, 0xFFFFFFFF);
        ctx.fill(p.x, y, p.x + W, y + 2, 0xF00F0F14);
        ctx.fill(p.x, y + 2 + h, p.x + W, y + 2 + h + 2, 0xF00F0F14);

        Drag setter = (mx, my) -> hsb[channel] = (float) Math.max(0, Math.min(1, (mx - x1) / (double) (w - 1)));
        regions.add(new Region(p.x, y, p.x + W, y + h + 4, (b, a, d) -> setter.on(a, d), setter));
        return y + h + 4;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        for (int i = regions.size() - 1; i >= 0; i--) {
            Region r = regions.get(i);
            if (r.hit(click.x(), click.y())) {
                r.click().on(click.button(), click.x(), click.y());
                active = r.drag() != null ? r : null;
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (active != null && active.drag() != null) {
            active.drag().on(click.x(), click.y());
            return true;
        }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        active = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }
}
