package net.nova.module;

import net.minecraft.client.MinecraftClient;
import net.nova.module.render.SpawnerFinder;
import net.nova.module.render.StorageFinder;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    private ModuleManager() {}

    public static void init() {
        MODULES.add(new StorageFinder());
        MODULES.add(new SpawnerFinder());
    }

    public static List<Module> all() { return MODULES; }

    public static List<Module> in(Module.Category category) {
        return MODULES.stream().filter(m -> m.category == category).toList();
    }

    public static void tick(MinecraftClient mc) {
        for (Module m : MODULES) {
            if (m.isEnabled()) m.onTick(mc);
        }
    }
}
