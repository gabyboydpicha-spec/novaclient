package net.nova.module.render;

import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DropperBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;

/** Met en évidence les conteneurs : coffres, shulker boxes, droppers (+ options). */
public class StorageFinder extends BlockESP {
    public StorageFinder() {
        super("StorageFinder", "Repère les coffres, shulker boxes et droppers.");
        target("Coffres", true, 0xFFA726, be -> be instanceof ChestBlockEntity && !(be instanceof TrappedChestBlockEntity));
        target("Coffres piégés", true, 0xEF5350, be -> be instanceof TrappedChestBlockEntity);
        target("Shulker boxes", true, 0xAB47BC, be -> be instanceof ShulkerBoxBlockEntity);
        target("Droppers", true, 0x90A4AE, be -> be instanceof DropperBlockEntity);
        target("Barils", false, 0x8D6E63, be -> be instanceof BarrelBlockEntity);
    }
}
