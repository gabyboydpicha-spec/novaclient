package net.nova.module.render;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.chunk.WorldChunk;
import net.nova.module.Module;
import net.nova.setting.Setting;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 * Base commune des modules de détection de blocs : scan des block entities chargées,
 * puis affichage via ESPRenderer (contours / remplissage / les deux).
 */
public abstract class BlockESP extends Module {
    public record Hit(Box box, int rgb) {}

    protected static final class Target {
        final Setting.Bool enabled;
        final Setting.Color color;
        final Predicate<BlockEntity> test;

        Target(Setting.Bool enabled, Setting.Color color, Predicate<BlockEntity> test) {
            this.enabled = enabled;
            this.color = color;
            this.test = test;
        }
    }

    public final Setting.Mode style = add(new Setting.Mode("Mode", 2, "Contours", "Remplissage", "Contours + remplissage"));
    public final Setting.Num outlineOpacity = add(new Setting.Num("Opacité contours", 90, 0, 100));
    public final Setting.Num fillOpacity = add(new Setting.Num("Opacité remplissage", 25, 0, 100));
    public final Setting.Num range = add(new Setting.Num("Portée (blocs)", 128, 16, 256));
    public final Setting.Bool throughWalls = add(new Setting.Bool("À travers les murs", true));

    private final List<Target> targets = new ArrayList<>();
    private volatile List<Hit> hits = List.of();
    private int tickCounter;

    protected BlockESP(String name, String description) {
        super(name, description, Category.RENDER);
    }

    /** Déclare un type de bloc ciblé avec son interrupteur et sa couleur personnalisable. */
    protected void target(String label, boolean enabledByDefault, int rgb, Predicate<BlockEntity> test) {
        Setting.Bool on = add(new Setting.Bool(label, enabledByDefault));
        Setting.Color color = add(new Setting.Color("Couleur " + label, rgb));
        targets.add(new Target(on, color, test));
    }

    public List<Hit> hits() { return hits; }

    public boolean drawsOutline() { return style.index() != 1; }
    public boolean drawsFill() { return style.index() != 0; }

    @Override
    protected void onDisable() { hits = List.of(); }

    @Override
    public void onTick(MinecraftClient mc) {
        if (++tickCounter % 10 != 0) return; // rescan 2x par seconde
        ClientWorld world = mc.world;
        ClientPlayerEntity player = mc.player;
        if (world == null || player == null) { hits = List.of(); return; }

        ChunkPos center = player.getChunkPos();
        int chunkRadius = (int) Math.ceil(range.get() / 16.0);
        double maxDistSq = range.get() * range.get();
        List<Hit> found = new ArrayList<>();

        for (int dx = -chunkRadius; dx <= chunkRadius; dx++) {
            for (int dz = -chunkRadius; dz <= chunkRadius; dz++) {
                WorldChunk chunk = world.getChunkManager().getWorldChunk(center.x + dx, center.z + dz);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    BlockPos pos = be.getPos();
                    if (pos.getSquaredDistance(player.getPos()) > maxDistSq) continue;
                    for (Target t : targets) {
                        if (t.enabled.get() && t.test.test(be)) {
                            found.add(new Hit(boxOf(world, be), t.color.rgb()));
                            break;
                        }
                    }
                }
            }
        }
        hits = found;
    }

    private static Box boxOf(ClientWorld world, BlockEntity be) {
        BlockPos pos = be.getPos();
        VoxelShape shape = be.getCachedState().getOutlineShape(world, pos);
        return shape.isEmpty() ? new Box(pos) : shape.getBoundingBox().offset(pos);
    }
}
