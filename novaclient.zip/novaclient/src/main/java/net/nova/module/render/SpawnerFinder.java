package net.nova.module.render;

import net.minecraft.block.entity.MobSpawnerBlockEntity;

/** Met en évidence les générateurs de monstres. */
public class SpawnerFinder extends BlockESP {
    public SpawnerFinder() {
        super("SpawnerFinder", "Repère les générateurs de monstres (spawners).");
        target("Spawners", true, 0x42A5F5, be -> be instanceof MobSpawnerBlockEntity);
    }
}
