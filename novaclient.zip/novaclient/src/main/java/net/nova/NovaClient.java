package net.nova;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import net.nova.config.Config;
import net.nova.gui.ClickGuiScreen;
import net.nova.module.ModuleManager;
import net.nova.render.ESPRenderer;
import org.lwjgl.glfw.GLFW;

public class NovaClient implements ClientModInitializer {
    private static KeyBinding guiKey;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        Config.load();

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nova.gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.create(Identifier.of("nova", "main"))));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (guiKey.wasPressed()) {
                mc.setScreen(new ClickGuiScreen());
            }
            if (mc.world != null && mc.player != null) {
                ModuleManager.tick(mc);
            }
        });

        WorldRenderEvents.AFTER_TRANSLUCENT.register(ESPRenderer::render);
    }
}
